# E-Klinik-proyek-kuliah
Aplikasi untuk Tugas Akhir Mata Kuliah Pemrograman Web. Aplikasi E-Klinik adalah sebuah Sistem Informasi Klinik sederhana yang dapat melakukan pendaftaran(pasien) dan mengelola data pasien(admin, dokter umum, poliklinik)

Anggota yang berkontribusi:
1. Ahmad Fadhil Rizqullah
2. Naufal Duta Maulana
3. Agus Bisana Putra
4. <a href="https://github.com/masyuraC7">Masyura Fanni Ramadhan</a>
5. Pramagita Dewandra
